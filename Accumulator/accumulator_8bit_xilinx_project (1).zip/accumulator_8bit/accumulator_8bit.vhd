library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity accumulator_8bit is
    Port ( CLK   : in  STD_LOGIC;
           RESET : in  STD_LOGIC;
           A     : in  STD_LOGIC_VECTOR (7 downto 0);
           B     : in  STD_LOGIC_VECTOR (7 downto 0);
           Q     : out STD_LOGIC_VECTOR (7 downto 0));
end accumulator_8bit;

architecture Structural of accumulator_8bit is

    -- ===== 8-bit adder portion (reused, unchanged) =====
    component adder_8bit
        Port ( A    : in  STD_LOGIC_VECTOR (7 downto 0);
               B    : in  STD_LOGIC_VECTOR (7 downto 0);
               CIN  : in  STD_LOGIC;
               SUM  : out STD_LOGIC_VECTOR (7 downto 0);
               COUT : out STD_LOGIC);
    end component;

    -- ===== 8-bit register portion (reused, unchanged) =====
    component register_8bit_dff
        Port ( CLK   : in  STD_LOGIC;
               RESET : in  STD_LOGIC;
               LOAD  : in  STD_LOGIC;
               D0, D1, D2, D3, D4, D5, D6, D7 : in  STD_LOGIC;
               Q0, Q1, Q2, Q3, Q4, Q5, Q6, Q7 : out STD_LOGIC);
    end component;

    signal sum_int  : STD_LOGIC_VECTOR (7 downto 0);
    signal cout_int : STD_LOGIC;  -- computed but not exposed (per spec diagram)

begin

    -- ---- Adder stage: combinational, SUM = A + B (CIN tied low) ----
    ADD: adder_8bit port map (
        A    => A,
        B    => B,
        CIN  => '0',
        SUM  => sum_int,
        COUT => cout_int
    );

    -- ---- Register stage: captures SUM on every rising CLK edge.     ----
    -- LOAD is tied high so the accumulator always loads the new sum  ----
    -- unless RESET is asserted; RESET has priority (see              ----
    -- register_1bit_dff's internal D_ff <= '0' when RESET='1' ...)   ----
    REG: register_8bit_dff port map (
        CLK   => CLK,
        RESET => RESET,
        LOAD  => '1',
        D0 => sum_int(0), D1 => sum_int(1), D2 => sum_int(2), D3 => sum_int(3),
        D4 => sum_int(4), D5 => sum_int(5), D6 => sum_int(6), D7 => sum_int(7),
        Q0 => Q(0), Q1 => Q(1), Q2 => Q(2), Q3 => Q(3),
        Q4 => Q(4), Q5 => Q(5), Q6 => Q(6), Q7 => Q(7)
    );

end Structural;
